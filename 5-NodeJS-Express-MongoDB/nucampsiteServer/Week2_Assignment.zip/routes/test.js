/*
1. create the array
2. create the function
3. call the array
4. parse content of array to get individual letter of content
5. create a new array with individual letter for comparison
6. compare the letter to find matching result

*/

let items1 = ["ABAZDC", "BACBAD"];

let compare1 = function (s1, s2) {
  let set1 = s1.map(items1[0]);
  console.log(set1);
};

compare1();
